/* 黴　かび — 黴のなかへ：下へ進むと、章ごとに黴が育つ（スクロールは止めない）。10/27 晚：章扉（中央の大きな字）→ 作品と説明の二段 */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var secs = $$('.k-sec'), idx = $$('.k-idx a');
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var still = false;
  try { still = localStorage.getItem('kabi-still') === '1'; } catch (e) {}
  if (mq && mq.matches) still = true;

  function setLang(l) {
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
  }
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-set-lang]'); if (b) setLang(b.dataset.setLang); });

  function setStill(s) {
    still = s; document.body.classList.toggle('still', s);
    var b = $('.k-still'); b.setAttribute('aria-pressed', s ? 'true' : 'false');
    try { localStorage.setItem('kabi-still', s ? '1' : '0'); } catch (e) {}
    frame();
  }
  $('.k-still').addEventListener('click', function () { setStill(!still); });

  var vh = window.innerHeight;
  function frame() {
    vh = window.innerHeight;
    var cur = 0;
    secs.forEach(function (s, i) {
      var r = s.getBoundingClientRect();
      var span = Math.max(1, r.height - vh);
      var p = Math.min(1, Math.max(0, -r.top / span));
      if (r.top < vh * .5) cur = i;
      // 章は二段：p 0–.34 で黴が育つ（章扉）、.28–.44 で字が左へ寄り作品と説明が出る（GPT：黴が育ちきるのを待たせない）。止めているときは途中を飛ばす
      var g, t;
      if (s.classList.contains('k-intro')) { g = still ? 1 : p; t = 0; }
      else {
        g = still ? 1 : Math.min(1, p / .34);
        var u = Math.min(1, Math.max(0, (p - .28) / .16));
        t = still ? (p > .36 ? 1 : 0) : u * u * (3 - 2 * u);
      }
      s.style.setProperty('--p', p.toFixed(4));
      s.style.setProperty('--g', g.toFixed(4));
      s.style.setProperty('--t', t.toFixed(4));
      s.classList.toggle('b2', t > .02);
      if (s.classList.contains('k-intro')) {
        var lines = $$('.k-line', s), n = lines.length;
        lines.forEach(function (ln, j) { ln.classList.toggle('on', still || p * (n + 1.2) > j + .3); });
      }
    });
    idx.forEach(function (a, i) { a.classList.toggle('on', i === cur); if (i === cur) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current'); });
  }
  var tick = false;
  window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(function () { tick = false; frame(); }); } }, { passive: true });
  window.addEventListener('resize', frame);
  idx.forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var t = document.getElementById(a.getAttribute('href').slice(1));
      var y = t.getBoundingClientRect().top + window.pageYOffset + (t.classList.contains('k-intro') ? 0 : vh * .35);
      window.scrollTo({ top: y, behavior: still ? 'auto' : 'smooth' });
    });
  });
  // キーボードで章扉のうちに作品・説明のリンクへ入ったら、その章の二段目まで送る（作品が大きな字に重ならないように）
  document.addEventListener('focusin', function (e) {
    var s = e.target.closest ? e.target.closest('.k-sec') : null;
    if (!s || s.classList.contains('k-intro') || s.classList.contains('b2') || !e.target.closest('.k-work, .k-txt')) return;
    var r = s.getBoundingClientRect();
    window.scrollTo({ top: r.top + window.pageYOffset + Math.max(1, r.height - vh) * .6, behavior: 'auto' });
  });
  setLang(root.dataset.lang || 'ja');
  setStill(still);
})();
