/* 黴　かび — 首頁：言語、上の帯、大きく見る、映像 */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 言語：切り替えても読んでいた場所から動かない ---------- */
  function setLang(l, keep) {
    var anchor = null, top = 0;
    if (keep) {
      var cands = $$('h2, h3, .wk, .chead, .toc li, .film, .card, .about li, .foot p');
      for (var i = 0; i < cands.length; i++) {
        var r = cands[i].getBoundingClientRect();
        if (r.bottom > 70) { anchor = cands[i]; top = r.top; break; }
      }
    }
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
    if (anchor) window.scrollBy(0, anchor.getBoundingClientRect().top - top);
    if (lb && !lb.hidden) render();
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-set-lang]');
    if (b) { e.preventDefault(); setLang(b.dataset.setLang, true); }
  });

  /* ---------- 上の帯：冒頭を過ぎたら出す。今の章を示す。下の地の色に合わせる ---------- */
  var bar = $('.bar'), hero = $('.hero');
  var chaps = $$('[data-ch]'), links = $$('.bar nav a');
  function onScroll() {
    if (!bar) return;
    var hb = hero.getBoundingClientRect().bottom;
    bar.classList.toggle('on', hb < 60);   // 10/30：40 → 60。目次に着いたとき（冒頭の下端が 56 px）にも帯が出て、冒頭の切れ端を覆う
    var cur = null;
    for (var i = 0; i < chaps.length; i++) { if (chaps[i].getBoundingClientRect().top < 120) cur = chaps[i].dataset.ch; }
    links.forEach(function (a) { a.classList.toggle('on', a.dataset.go === cur); });
    var under = document.elementFromPoint(window.innerWidth / 2, 70);
    var sec = under && under.closest('.s-paper, .s-night');
    if (sec) { bar.classList.toggle('s-paper', sec.classList.contains('s-paper')); bar.classList.toggle('s-night', !sec.classList.contains('s-paper')); }
  }
  var tick = false;
  window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(function () { tick = false; onScroll(); }); } }, { passive: true });
  window.addEventListener('resize', onScroll);

  /* ---------- 大きく見る ---------- */
  var DATA = JSON.parse($('#works-data').textContent);
  var W = DATA.works, byNo = {};
  W.forEach(function (w, i) { byNo[w.no] = i; });
  var lb = $('#lb'), cw = 0, ci = 0, opener = null;
  function T(o) { return o ? (root.dataset.lang === 'zh' ? (o.zh || o.ja) : (o.ja || o.zh)) : ''; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function L(ja, zh) { return root.dataset.lang === 'zh' ? zh : ja; }
  function render() {
    var w = W[cw], im = w.imgs[ci];
    var img = $('.mat img', lb);
    var o = $('.orig', lb); o.hidden = true;
    img.onload = fitOrig;
    img.src = DATA.base + 'img/w/' + im.k + '.webp';
    img.width = im.w; img.height = im.h; o.href = img.src;
    if (img.complete && img.naturalWidth) fitOrig();
    $('.mat', lb).classList.toggle('lt', !!im.lt);
    img.alt = w.title + (w.imgs.length > 1 ? '（' + (ci + 1) + '／' + w.imgs.length + '）' : '');
    $('.cnt', lb).textContent = w.imgs.length > 1 ? (ci + 1) + ' / ' + w.imgs.length : '';
    $('.ic', lb).textContent = im.c ? T(im.c) : '';
    $('.prev', lb).hidden = $('.next', lb).hidden = w.imgs.length < 2;
    var h = '<div class="no">' + w.no + '</div><h2 id="lb-t">' + esc(w.title) + (w.rb && root.dataset.lang === 'ja' ? '<span class="rb">' + esc(w.rb) + '</span>' : '') + '</h2><dl>';
    if (w.year) h += '<dt>' + L('年', '年份') + '</dt><dd class="mono">' + esc(w.year) + '</dd>';
    if (w.med && (w.med.ja || w.med.zh)) h += '<dt>' + L('技法', '媒材') + '</dt><dd>' + esc(T(w.med)) + '</dd>';
    (w.size || []).forEach(function (s) { h += '<dt>' + L('寸法', '尺寸') + '</dt><dd class="mono">' + esc(s) + '</dd>'; });
    w.role.forEach(function (r) { h += '<dt>' + L('担当', '負責') + '</dt><dd>' + esc(T(r).replace(/^(担当|負責)：/, '')) + '</dd>'; });
    h += '<dt>' + L('頁', '頁') + '</dt><dd class="mono">p.' + w.pg + '</dd></dl>';
    var nt = w.notes.concat(w.body || []);
    if (nt.length) h += '<div class="nt">' + nt.map(function (n) { return '<p>' + esc(T(n)) + '</p>'; }).join('') + '</div>';
    if (w.yt) h += '<a class="go" href="https://youtu.be/' + w.yt + '" target="_blank" rel="noopener">' + L('YouTube で見る', '在 YouTube 觀看') + '<span class="mono">↗</span></a><br>';
    h += '<a class="go" href="' + DATA.base + 'book/' + coverQ() + '#p' + parseInt(w.pg, 10) + '">' + L('作品集の頁で見る', '在作品集裡看') + '<span class="mono">p.' + w.pg + ' →</span></a>';   // 選んだ表紙を翻書に（GPT 全站 R1）
    h += '<div class="wnav"><button type="button" data-wstep="-1">← ' + L('前の作品', '上一件') + '</button><button type="button" data-wstep="1">' + L('次の作品', '下一件') + ' →</button></div>';
    $('.info', lb).innerHTML = h;
    // 前後の図を先に読む
    [ci + 1, ci - 1].forEach(function (j) { if (j >= 0 && j < w.imgs.length) { var p = new Image(); p.src = DATA.base + 'img/w/' + w.imgs[j].k + '.webp'; } });
  }
  // 原図が表示よりかなり大きいときだけ「原寸で開く」を出す（スライドの細かい字など）
  function fitOrig() {
    var img = $('.mat img', lb), o = $('.orig', lb);
    if (!img.naturalWidth || !img.clientWidth) return;
    o.hidden = !(img.naturalWidth > img.clientWidth * 1.5);
  }
  window.addEventListener('resize', function () { if (!lb.hidden) fitOrig(); });
  function open(no, i, from) {
    cw = byNo[no]; ci = i || 0; opener = from || null;
    render(); lb.hidden = false; document.body.classList.add('lb-open'); fitOrig();
    $('.close', lb).focus();
    if (history.replaceState) history.replaceState(history.state, '', '#w' + no);
  }
  function close() {
    lb.hidden = true; document.body.classList.remove('lb-open');
    $('.mat img', lb).removeAttribute('src');
    if (history.replaceState) history.replaceState(history.state, '', location.pathname + location.search);
    if (opener) opener.focus();
  }
  function step(d) { var n = W[cw].imgs.length; ci = (ci + d + n) % n; render(); }
  function wstep(d) { cw = (cw + d + W.length) % W.length; ci = 0; render(); if (history.replaceState) history.replaceState(history.state, '', '#w' + W[cw].no); }
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open]');
    if (t) { e.preventDefault(); open(t.dataset.open, parseInt(t.dataset.i || '0', 10), t); return; }
    if (lb.hidden) return;
    if (e.target.closest('.close')) close();
    else if (e.target.closest('.prev')) step(-1);
    else if (e.target.closest('.next')) step(1);
    else if (e.target.closest('[data-wstep]')) wstep(parseInt(e.target.closest('[data-wstep]').dataset.wstep, 10));
    else if (e.target === lb || e.target.classList.contains('stage')) close();
  });
  document.addEventListener('keydown', function (e) {
    if (lb.hidden) return;
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowRight') step(1);
    else if (e.key === 'ArrowLeft') step(-1);
    else if (e.key === 'Tab') {                       // 枠の中で回す
      var f = $$('button:not([hidden]), a[href]', lb).filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      var a = f[0], z = f[f.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    }
  });
  var sx = null;
  lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', function (e) {
    if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(dx) > 50 && W[cw].imgs.length > 1) step(dx < 0 ? 1 : -1);
  });

  /* ---------- 映像：押したときだけ YouTube を読み込む ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-yt]');
    if (!b) return;
    e.preventDefault();
    var f = document.createElement('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + b.dataset.yt + '?autoplay=1&rel=0&modestbranding=1&playsinline=1';
    f.title = b.getAttribute('aria-label') || 'video';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.allowFullscreen = true;
    b.replaceWith(f);
  });

  /* ---------- 表紙を選ぶ（10/27 深夜：本人の希望。翻書の表 1・表 4 が替わる。PDF は替わらない） ---------- */
  var COVS = { online: 'img/pg/c1.webp', print: 'img/pg/c1_print.webp', kin: 'img/pg/c1_kin.webp' };
  var HCOVS = { online: 'img/cover_l.webp', print: 'img/cover_l_print.webp', kin: 'img/cover_l_kin.webp' };
  var cover = 'online';
  try { var c0 = localStorage.getItem('kabi-cover'); if (COVS[c0]) cover = c0; } catch (e) {}
  // 翻書へのリンクに付ける表紙。三款ともいつも明示する（オンライン閲覧版も ?cover=online。別のタブで選んだ表紙が残らないように：GPT 全站 R1）
  function coverQ() { return '?cover=' + cover; }
  function setCover(k, save) {   // 読めている前提で、全部を一度に替える（大きい表紙・下線・身分・下の三款・翻書の表紙・連結・記憶）
    if (!COVS[k]) k = 'online'; cover = k;
    if (save) { try { localStorage.setItem('kabi-cover', k); } catch (e) {} }
    $$('[data-cover]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.cover === k ? 'true' : 'false'); });
    var hb = $('.hero .book'); if (hb) { if (hb.getAttribute('src') !== HCOVS[k]) hb.setAttribute('src', HCOVS[k]); hb.className = 'book cv-' + k; }   // 10/28 下午：首頁の表紙も選んだものに
    hstShow(k);   // 選んだ表紙の身分の一行（GPT R12 C）
    var hp = $('.hero .cvpdf'); if (hp) hp.hidden = k === 'online';    // 首頁の表紙が線上以外のとき、PDF の表紙は線上だと添える（GPT R6）
    var cv = $('.read .obj .cv'); if (cv && cv.getAttribute('src') !== COVS[k]) cv.setAttribute('src', COVS[k]);   // 「作品集を読む」の表紙と名前も同じ回に
    $$('.read .obj [data-cvname]').forEach(function (s) { s.hidden = s.dataset.cvname !== k; });
    // 保存できない環境（プライベート閲覧など）でも翻書に伝わるように、リンクにも付ける
    $$('a[href^="book/"]').forEach(function (a) {                     // 頁への連結（#p106 など）は頁番号を残す（GPT 全站 R1）
      var h = a.getAttribute('href'), i = h.indexOf('#');
      a.setAttribute('href', 'book/' + coverQ() + (i >= 0 ? h.slice(i) : ''));
    });
  }
  function hstShow(key) { $$('.hero [data-hst]').forEach(function (s) { s.hidden = s.dataset.hst !== key; }); }
  // 画像を読んで描ける状態にする（一度読めたものは覚えておく）
  var ready = {};
  function load(src) {
    if (ready[src]) return Promise.resolve();
    var im = new Image(); im.src = src;
    var p = im.decode ? im.decode() : new Promise(function (ok, ng) { im.onload = ok; im.onerror = ng; });
    return p.then(function () { ready[src] = true; });
  }
  // 10/30 GPT R13 必改：押した表紙の大きい画像が読めるまでは、下線・身分・連結などを前のままにする（表紙の絵と名前が食い違わない）。
  // その間は首頁の身分行と、下の三款の押したものに「読み込み中…」（120 ms 以内に読めたら出さない）。読めなかったら前のまま「読み込めませんでした」。
  // 続けて押したら最後のものだけ。いま選んでいるものを押したら待っているものを取り消す
  var reqTok = 0, pendT = 0, ngT = 0, sayT = 0;
  function tx(el) { if (!el) return ''; var c = el.querySelector(root.dataset.lang === 'zh' ? '.zh' : '.ja'); return (c || el).textContent.trim(); }   // いまの言語の文字だけ
  function say(s, t) { var r = $('#cvlive'); if (!r) return; clearTimeout(sayT); r.textContent = ''; sayT = setTimeout(function () { if (t === reqTok) r.textContent = s; }, 60); }   // 一度空にしてから入れる（同じ文でももう一度読まれる）。書く前に、まだ最後の選択か確かめる（GPT R16）
  function sayCover(k, t) { say(tx($('.hero .hsel .hlab')) + '：' + tx($('.hero .hsel [data-cover="' + k + '"]')) + '。' + tx($('.hero [data-hst="' + k + '"]')), t); }
  function clearMarks() { clearTimeout(pendT); clearTimeout(ngT); clearTimeout(sayT); $$('.cvo.ld, .cvo.ng').forEach(function (b) { b.classList.remove('ld', 'ng'); }); hstShow(cover); }
  function request(k, save) {
    if (!COVS[k]) k = 'online';
    var t = ++reqTok; clearMarks();
    var need = [HCOVS[k], COVS[k]];   // 首頁の大きい表紙と「作品集を読む」の表紙（GPT R16 必改：両方読めてから一度に）
    if (k === cover || (ready[need[0]] && ready[need[1]])) { setCover(k, save); if (save) sayCover(k, t); return; }
    pendT = setTimeout(function () { if (t !== reqTok) return; hstShow('ld-' + k); var b = $('.cvo[data-cover="' + k + '"]'); if (b) b.classList.add('ld'); if (save) say(tx($('.hero [data-hst="ld-' + k + '"]')), t); }, 120);
    Promise.all(need.map(load)).then(function () { if (t !== reqTok) return; clearMarks(); setCover(k, save); if (save) sayCover(k, t); },
      function () { if (t !== reqTok) return; clearMarks(); hstShow('ng'); var b = $('.cvo[data-cover="' + k + '"]'); if (b) b.classList.add('ng'); if (save) say(tx($('.hero [data-hst="ng"]')), t);
        ngT = setTimeout(function () { if (t === reqTok) clearMarks(); }, 4000); });
  }
  // 頁が落ち着いてから三款とも先に読んでおく（ほかの二款：大きい表紙 57 KB・34 KB、作品集を読むの表紙 24 KB・19 KB）。選ぶところに触れたときも
  var warmed = false;
  function warm() { if (warmed) return; warmed = true; Object.keys(HCOVS).forEach(function (k) { load(HCOVS[k]).catch(function () {}); load(COVS[k]).catch(function () {}); }); }   // 三款とも（いま出ているものも load() を通して ready に：GPT R16）
  window.addEventListener('load', function () { if (window.requestIdleCallback) requestIdleCallback(warm, { timeout: 3000 }); else setTimeout(warm, 1500); });
  ['pointerenter', 'focusin', 'touchstart'].forEach(function (n) { $$('.hero .hsel, #covers .cv3').forEach(function (g) { g.addEventListener(n, warm, { once: true, passive: true }); }); });
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-cover]'); if (b) request(b.dataset.cover, true); });
  setCover(cover, false);
  function storedCover() { try { var c = localStorage.getItem('kabi-cover'); if (COVS[c]) return c; } catch (e) {} return cover; }
  window.addEventListener('pageshow', function (e) { if (e.persisted) request(storedCover(), false); });   // 上一頁で戻ったとき（bfcache）も、いまの表紙に（GPT R6）
  window.addEventListener('storage', function (e) { if (e.key === 'kabi-cover' && COVS[e.newValue]) request(e.newValue, false); });   // 別の分頁で選んだとき
  /* ---------- 頁の中の移動（10/28 晚 本人「按這個鍵以後 頁面應該是滑到那個位置」「是否要加一個鍵是回到最上面」→ GPT 第十一輪） ----------
     遠いところは全部を流さない（選擇區まで桌機 15,000 px・手機 22,000 px。作品が高速で流れるだけで、途中の図も読み込まれる）。
     目的地の手前（最大 200 px、手機は見えている高さの 30% まで）へ一度に移り、残りを 320 ms で滑らせて止める（だんだん遅く、はね返らない）。
     動きを減らす設定では一度に。ホイール・タッチ・つまみ・キー（Tab も）が入ったら残りの動きはやめ、焦点も動かさない。 */
  function docY(el) { return el.getBoundingClientRect().top + window.pageYOffset; }
  function barH() { var b = $('.bar'); return b ? b.offsetHeight : 56; }
  var glideStop = null;
  function glide(toY, done) {
    if (glideStop) glideStop();
    var max = document.documentElement.scrollHeight - window.innerHeight;
    toY = Math.max(0, Math.min(Math.round(toY), max));
    if (reduce) { window.scrollTo(0, toY); if (done) done(true); return; }
    var lead = Math.min(200, Math.round(window.innerHeight * 0.3)), y0 = window.pageYOffset;
    if (Math.abs(toY - y0) > lead) { window.scrollTo(0, toY + (toY > y0 ? -lead : lead)); y0 = window.pageYOffset; }
    var dist = toY - y0, t0 = null, live = true, D = 320, EV = ['wheel', 'touchstart', 'pointerdown', 'keydown'];
    function off() { EV.forEach(function (n) { window.removeEventListener(n, stop, true); }); glideStop = null; }
    function stop() { if (!live) return; live = false; off(); if (done) done(false); }
    EV.forEach(function (n) { window.addEventListener(n, stop, true); });
    glideStop = stop;
    if (!dist) { live = false; off(); if (done) done(true); return; }
    requestAnimationFrame(function step(ts) {
      if (!live) return;
      if (t0 === null) t0 = ts;
      var k = Math.min(1, (ts - t0) / D);
      window.scrollTo(0, y0 + dist * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(step); else { live = false; off(); if (done) done(true); }
    });
  }
  function focusQuiet(el) { if (!el) return; if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1'); try { el.focus({ preventScroll: true }); } catch (x) { el.focus(); } }
  function plain(e) { return !(e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey); }
  // 履歴：自分で積んだ項目に { 前の項目, 押した連結, 着いた先 } を覚えておく。上一頁なら押した連結へ、下一頁なら着いた先へ焦點を戻す（GPT 第十一輪）
  //   同じ所への移動は積まない（瀏覽器の錨點と同じ）。章の連結など普通の錨點の項目にも印を付けて、どこから来たか分かるようにする
  var navSeq = 0, navRec = {};
  function stId() { var s = history.state; return s && s.kabiNav; }
  function tag() { if (!stId()) { try { history.replaceState({ kabiNav: 'n' + (++navSeq) + '.' + Date.now() }, '', location.href); } catch (x) {} } return stId(); }
  var navCur = tag();
  function navTo(hash, opener, target) {
    if (location.hash === hash) return;
    var from = tag(), id = 'n' + (++navSeq) + '.' + Date.now();
    try { history.pushState({ kabiNav: id }, '', hash); } catch (x) { return; }
    navRec[id] = { from: from, opener: opener, target: target }; navCur = id;
  }
  window.addEventListener('hashchange', function () { navCur = tag(); });
  window.addEventListener('popstate', function () {
    if (glideStop) glideStop();
    var to = stId(), was = navCur, r = navRec[was], f = navRec[to]; navCur = to;
    if (r && r.from === to) { if (document.contains(r.opener)) focusQuiet(r.opener); }          // 上一頁：押した連結に（画面の位置は瀏覽器が戻す）
    else if (f && f.from === was) { if (document.contains(f.target)) focusQuiet(f.target); }    // 下一頁：着いた先に
  });
  // 頁の先頭へ（選擇區の「↑ ページの先頭へ」と上の帯の「黴」）：同じ滑り方で一番上へ。焦點は冒頭（読み上げ名「作品集『黴』の冒頭」）に
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a.totop, .bar a.home'); if (!a || !plain(e)) return;
    var top = $('#top'); e.preventDefault();
    navTo('#top', a, top);
    glide(0, function (ok) { if (ok) focusQuiet(top); });
  });

  /* 函から出す動きは、翻書の頭でだけ（book.js。10/27 深夜（續）本人「一開始是有書殼…按下一頁會有個動畫是從書殼抽出」）。首頁では動かさない */

  /* ---------- 読み込み時 ---------- */
  setLang(root.dataset.lang || 'ja', false);
  onScroll();
  function fromHash() {
    var m = /^#w(\d\d)$/.exec(location.hash);
    if (m && byNo[m[1]] !== undefined) { if (lb.hidden) open(m[1], 0, null); else { cw = byNo[m[1]]; ci = 0; render(); } }
  }
  fromHash();
  window.addEventListener('hashchange', fromHash);
  // 翻書・走進黴裡の「作品一覧へ」（../#toc）から来たとき、焦點は目次へ（GPT R12 必改）：目次の section に tabindex="-1" を付けてあり、
  // 瀏覽器が錨點へ移るときに自分で焦點を置く（10/30：ここで見出しに置いても、そのあと瀏覽器の錨點の処理で外されていた）
  if (reduce) root.style.scrollBehavior = 'auto';

  /* ---------- 捲動で少しずつ出す（10/31 本人：Apple の Mac の頁のように。11/1 本人：まだ見えにくい → GPT 第 14〜16 輪と作り直し） ----------
     図（台紙ごと .im）、図説（.cap）、豆本の説明（.tx）、カードの説明（.nt）、章頭の三つ、根の小見出しを、それぞれ自分の位置で出す（図が先、字があと）。
     動く前の上の端が画面の 85% まで来たら始まる。下から：図は自分の高さの 1 割（24〜40 px）、図説は 14 px。同じ列の図は左から 90 ms ずつ（0／90／180／270）。
     図説は自分の位置で始まる。同じ作品の図が始まったばかりなら、図より 120 ms あと。
     速さでは打ち切らない。中心が画面の 60% より上に来てもまだのものは、今の見え方から 180 ms で出しきる（一度に変えない）。
     捲るのを止めて 150 ms：画面に少しでも入っているものは始める（下の端に出ないまま残さない）。
     一度に画面の 0.6 以上動いた／頁の中の連結／上一頁・下一頁／bfcache で戻った：着いた画面とその上はすぐ全部見えるように。その下はそのまま。
     焦點が来た・押した：その作品の図と図説だけすぐ出しきる（図がもう出しきっていても図説まで）。
     出しきったら class と変数を外して元の見た目に戻す（滑過の放大と細い縁はそのまま。位移は transform でなく translate なので滑過の scale と重ならない）。
     普通に開いて上から読むときだけ。JS がない・減らす設定・錨點つきで来た・上一頁などで来たときは最初から全部見えたまま。読み込んだときに画面に入っているもの・その上も、そのまま。
     見ている途中で減らす設定にした → 全部すぐ出しきる。画面の大きさが変わった → まだのものの距離と列を数え直す。 */
  var RVC = {
    line: 0.85, center: 0.6, idle: 150, quick: 180, rowStep: 90, txtGap: 120, headStep: 80,
    img: { y: 0, o: 700, t: 850, e: 'cubic-bezier(.22,.61,.36,1)' },   // y 0：自分の高さの 1 割（24〜40 px）
    txt: { y: 14, o: 450, t: 500, e: 'cubic-bezier(.2,.7,.2,1)' },
    head: { y: 36, o: 700, t: 850, e: 'cubic-bezier(.22,.61,.36,1)' },
    sub: { y: 36, o: 700, t: 850, e: 'cubic-bezier(.22,.61,.36,1)' },
    headSel: '.chead', headKids: '.g, .meta, .pp', subSel: '.chap > .sub-h', unit: '.chap .row > .wk, .mame > *, .cards > .card'
  };
  var navE = null, navT = 'navigate';
  try { navE = performance.getEntriesByType('navigation')[0]; } catch (x) {}
  if (navE && navE.type) navT = navE.type;
  else if (performance.navigation) navT = ['navigate', 'reload', 'back_forward'][performance.navigation.type] || 'navigate';
  if (!reduce && 'IntersectionObserver' in window && !location.hash && navT === 'navigate') {
    var vh0 = window.innerHeight, items = [], live = [];
    var hasTr = !!(window.CSS && CSS.supports && CSS.supports('translate', '0px 1px'));   // translate がない瀏覽器：淡入だけ（位置は動かない）
    var below = function (el) { return !el.closest('.lb') && el.getBoundingClientRect().top >= vh0; };   // 画面に入っている・上：そのまま
    var imgY = function (el) { return Math.round(Math.max(24, Math.min(40, el.offsetHeight * 0.1))); };
    var add = function (el, kind, grp, ref) {
      if (!el || el._rvi) return null;
      var c = RVC[kind], y = c.y || imgY(el);
      var it = { el: el, kind: kind, grp: grp, ref: ref || el, y: y, col: 0, d: 0 };
      el._rvi = it; el.classList.add('rv');
      el.style.setProperty('--rvy', y + 'px'); el.style.setProperty('--rvo', c.o + 'ms'); el.style.setProperty('--rvt', c.t + 'ms'); el.style.setProperty('--rve', c.e);
      items.push(it); return it;
    };
    $$(RVC.headSel).forEach(function (g) {   // 章頭：大字・番号と一行・頁碼の順に（章頭そのものの位置で）
      if (!below(g)) return;
      $$(RVC.headKids, g).forEach(function (k, i) { var it = add(k, 'head', g, g); if (it) it.d = Math.min(i, 2) * RVC.headStep; });
    });
    $$(RVC.subSel).forEach(function (el) { if (below(el)) add(el, 'sub', el); });
    var units = $$(RVC.unit).filter(below);
    var cols = function () {   // 列の中の順（左から）
      units.forEach(function (u) { var r = u.getBoundingClientRect(); u._t = r.top; u._l = r.left; });
      units.forEach(function (u) { u._c = units.filter(function (v) { return v.parentNode === u.parentNode && Math.abs(v._t - u._t) < 40 && v._l < u._l - 4; }).length; });
    };
    cols();
    units.forEach(function (u) {   // 作品：図と図説を別に
      var tx = u.matches('.tx'), g = tx ? (u.parentNode.querySelector(':scope > .wk') || u) : u;   // 豆本の説明は図と同じ作品
      var im = tx ? ((u.parentNode.querySelector(':scope > .wk > .im') || {})._rvi || null) : add(u.matches('.wk') ? u.querySelector(':scope > .im') : u.querySelector('.wk > .im'), 'img', g);
      if (im && !tx) im.unit = u;
      (tx ? [u] : $$(':scope > .cap, .wk > .cap, :scope > .nt', u)).forEach(function (t) { var it = add(t, 'txt', g); if (it) it.img = im; });
    });
    var ty = function (el) { var s = getComputedStyle(el).translate; if (!s || s === 'none') return 0; var a = s.split(' '); return a[1] ? parseFloat(a[1]) || 0 : 0; };
    var shift = function (it) { return it.ref !== it.el || !hasTr ? 0 : (it.st ? ty(it.el) : it.y); };   // 動く前の位置に直す量
    var clean = function (it) {   // 出しきった：元の見た目に戻す
      if (it.fin) return; it.fin = 1; var el = it.el;
      el.classList.remove('rv', 'rv-in', 'rv-now'); el.style.opacity = ''; el.style.translate = '';
      ['--rvy', '--rvo', '--rvt', '--rve', '--rvd'].forEach(function (p) { el.style.removeProperty(p); });
      var i = live.indexOf(it); if (i >= 0) live.splice(i, 1);
    };
    var now1 = function (it) { if (it.fin) return; it.el.classList.add('rv-now'); clean(it); };
    var start = function (it, d) {
      if (it.st || it.fin) return; d = isFinite(d) ? Math.max(0, Math.round(d)) : 0;
      it.st = 1; it.t0 = Date.now() + d;
      it.el.style.setProperty('--rvd', d + 'ms'); it.el.classList.add('rv-in');
      var c = RVC[it.kind]; setTimeout(function () { clean(it); }, d + Math.max(c.o, c.t) + 60);
    };
    var quick = function (it) {   // もう読む位置に来た：今の見え方から短い時間で出しきる
      if (it.fin || it.q) return; it.q = 1; var el = it.el, q = RVC.quick, c = RVC[it.kind], now = Date.now();
      if (it.st && it.t0 <= now && it.t0 + Math.max(c.o, c.t) - now <= q) return;   // もうすぐ出しきるものは、そのまま（長くしない）
      if (it.st) { var cs = getComputedStyle(el), o = cs.opacity, tr = cs.translate; el.classList.add('rv-now'); el.style.opacity = o; el.style.translate = tr; el.offsetWidth; el.classList.remove('rv-now'); }
      if (!it.st || it.t0 > now) it.t0 = now;   // 始まっていない・順番を待っていたもの：いま始まったことに
      el.style.setProperty('--rvo', q + 'ms'); el.style.setProperty('--rvt', q + 'ms'); el.style.setProperty('--rvd', '0ms'); el.style.setProperty('--rve', RVC.txt.e);
      if (!it.st) { it.st = 1; el.classList.add('rv-in'); } else { el.style.opacity = ''; el.style.translate = ''; }
      setTimeout(function () { clean(it); }, q + 60);
    };
    var settle = function (lim) {   // 着いた画面とその上：すぐ全部見えるように（その下はそのまま）
      if (lim == null) lim = window.innerHeight;
      items.forEach(function (it) { if (it.fin) return; if (it.ref.getBoundingClientRect().top - shift(it) < lim) now1(it); });
    };
    var raf = 0, idT = 0, lastY = window.pageYOffset;
    var step = function (idle) {
      raf = 0; var vh = window.innerHeight, line = vh * RVC.line, mid = vh * RVC.center, hit = [];
      live.slice().forEach(function (it) {
        if (it.fin) return;
        var r = it.ref.getBoundingClientRect(), top = r.top - shift(it);
        if (top + r.height / 2 < mid) { quick(it); return; }
        if (it.st) return;
        if (top < line || (idle === true && top < vh - 2)) hit.push([top, r.left, it]);
      });
      hit.sort(function (a, b) { return (Math.round(a[0] / 40) - Math.round(b[0] / 40)) || (a[1] - b[1]); });
      hit.forEach(function (h) {
        var it = h[2], d = it.kind === 'head' ? it.d : it.kind === 'img' ? Math.min(it.unit ? it.unit._c : 0, 3) * RVC.rowStep : 0;
        if (it.kind === 'txt' && it.img && !it.img.fin) {   // 図説は図のあと
          if (!it.img.st) start(it.img, Math.min(it.img.unit ? it.img.unit._c : 0, 3) * RVC.rowStep);
          if (!it.img.q && it.img.t0 != null) d = Math.max(d, it.img.t0 + RVC.txtGap - Date.now());
        }
        start(it, d);
      });
    };
    var kick = function () { if (!raf) raf = requestAnimationFrame(step); };
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        var it = en.target._rvi; if (!it || it.fin) return;
        if (en.isIntersecting) { if (live.indexOf(it) < 0) live.push(it); }
        else {
          var i = live.indexOf(it); if (i >= 0 && en.boundingClientRect.top >= window.innerHeight) live.splice(i, 1);
          if (en.boundingClientRect.bottom <= 0) now1(it);   // 見ないまま上へ行った
        }
      });
      kick();
    }, { rootMargin: '0px 0px 60px 0px' });
    items.forEach(function (it) { io.observe(it.el); });
    window.addEventListener('scroll', function () {
      var y = window.pageYOffset, dy = Math.abs(y - lastY); lastY = y;
      if (dy > window.innerHeight * 0.6) settle();   // 一度に大きく動いた（捲軸を引いた・飛んだ）
      kick(); clearTimeout(idT); idT = setTimeout(function () { step(true); }, RVC.idle);
    }, { passive: true });
    var rsT = 0;
    window.addEventListener('resize', function () {   // 画面の大きさが変わった：まだのものの距離と列を数え直してから
      kick(); clearTimeout(rsT);
      rsT = setTimeout(function () {
        cols();
        items.forEach(function (it) { if (it.st || it.fin || it.kind !== 'img') return; it.y = imgY(it.el); it.el.style.setProperty('--rvy', it.y + 'px'); });
        step(true);
      }, 200);
    });
    document.addEventListener('click', function (e) {   // 頁の中の連結：飛ぶ前に、着く画面とその上を見えるように（ほかは止めない）
      var a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a) return;
      var id = decodeURIComponent(a.getAttribute('href').slice(1)), t = id ? document.getElementById(id) : null;
      if (t) settle(t.getBoundingClientRect().top + window.innerHeight);
    }, true);
    var later = function () { requestAnimationFrame(function () { settle(); requestAnimationFrame(function () { settle(); }); }); };
    window.addEventListener('hashchange', later);
    window.addEventListener('popstate', later);
    window.addEventListener('pageshow', function (e) { if (e.persisted) settle(); });
    var rvOne = function (e) {   // 焦點・押したもの：その作品だけ（図がもう出しきっていても、同じ作品の図説まで）
      var t = e.target; if (!t || !t.closest) return;
      var u = t.closest('.rv'), g = u && u._rvi ? u._rvi.grp : t.closest(RVC.headSel + ', ' + RVC.subSel + ', ' + RVC.unit);
      if (!g) return; if (g.parentNode && g.parentNode.matches && g.parentNode.matches('.mame')) g = g.parentNode;
      items.forEach(function (o) { if (o.grp === g || g.contains(o.el)) now1(o); });
    };
    document.addEventListener('focusin', rvOne);   // 透明なところに焦點を置かない
    document.addEventListener('pointerdown', rvOne, true);
    var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    var onMq = function () { if (mq.matches) items.forEach(now1); };   // 見ている途中で減らす設定にした
    if (mq) { if (mq.addEventListener) mq.addEventListener('change', onMq); else if (mq.addListener) mq.addListener(onMq); }
    root.classList.add('rv-on');
  }
})();
