/* 黴　かび — 首頁：言語、上の帯、大きく見る、映像 */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 言語：切り替えても読んでいた場所から動かない ---------- */
  function setLang(l, keep) {
    var anchor = null, top = 0;
    if (keep) {
      var cands = $$('h2, h3, .wk, .chead, .toc li, .film, .card, .about li, .foot p');
      for (var i = 0; i < cands.length; i++) {
        var r = cands[i].getBoundingClientRect();
        if (r.bottom > 70) { anchor = cands[i]; top = r.top; break; }
      }
    }
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
    if (anchor) window.scrollBy(0, anchor.getBoundingClientRect().top - top);
    if (lb && !lb.hidden) render();
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-set-lang]');
    if (b) { e.preventDefault(); setLang(b.dataset.setLang, true); }
  });

  /* ---------- 上の帯：冒頭を過ぎたら出す。今の章を示す。下の地の色に合わせる ---------- */
  var bar = $('.bar'), hero = $('.hero');
  var chaps = $$('[data-ch]'), links = $$('.bar nav a');
  function onScroll() {
    if (!bar) return;
    var hb = hero.getBoundingClientRect().bottom;
    bar.classList.toggle('on', hb < 60);   // 10/30：40 → 60。目次に着いたとき（冒頭の下端が 56 px）にも帯が出て、冒頭の切れ端を覆う
    var cur = null;
    for (var i = 0; i < chaps.length; i++) { if (chaps[i].getBoundingClientRect().top < 120) cur = chaps[i].dataset.ch; }
    links.forEach(function (a) { a.classList.toggle('on', a.dataset.go === cur); });
    var under = document.elementFromPoint(window.innerWidth / 2, 70);
    var sec = under && under.closest('.s-paper, .s-night');
    if (sec) { bar.classList.toggle('s-paper', sec.classList.contains('s-paper')); bar.classList.toggle('s-night', !sec.classList.contains('s-paper')); }
  }
  var tick = false;
  window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(function () { tick = false; onScroll(); }); } }, { passive: true });
  window.addEventListener('resize', onScroll);

  /* ---------- 大きく見る ---------- */
  var DATA = JSON.parse($('#works-data').textContent);
  var W = DATA.works, byNo = {};
  W.forEach(function (w, i) { byNo[w.no] = i; });
  var lb = $('#lb'), cw = 0, ci = 0, opener = null;
  function T(o) { return o ? (root.dataset.lang === 'zh' ? (o.zh || o.ja) : (o.ja || o.zh)) : ''; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function L(ja, zh) { return root.dataset.lang === 'zh' ? zh : ja; }
  function render() {
    var w = W[cw], im = w.imgs[ci];
    var img = $('.mat img', lb);
    var o = $('.orig', lb); o.hidden = true;
    img.onload = fitOrig;
    img.src = DATA.base + 'img/w/' + im.k + '.webp';
    img.width = im.w; img.height = im.h; o.href = img.src;
    if (img.complete && img.naturalWidth) fitOrig();
    $('.mat', lb).classList.toggle('lt', !!im.lt);
    img.alt = w.title + (w.imgs.length > 1 ? '（' + (ci + 1) + '／' + w.imgs.length + '）' : '');
    $('.cnt', lb).textContent = w.imgs.length > 1 ? (ci + 1) + ' / ' + w.imgs.length : '';
    $('.ic', lb).textContent = im.c ? T(im.c) : '';
    $('.prev', lb).hidden = $('.next', lb).hidden = w.imgs.length < 2;
    var h = '<div class="no">' + w.no + '</div><h2 id="lb-t">' + esc(w.title) + (w.rb && root.dataset.lang === 'ja' ? '<span class="rb">' + esc(w.rb) + '</span>' : '') + '</h2><dl>';
    if (w.year) h += '<dt>' + L('年', '年份') + '</dt><dd class="mono">' + esc(w.year) + '</dd>';
    if (w.med && (w.med.ja || w.med.zh)) h += '<dt>' + L('技法', '媒材') + '</dt><dd>' + esc(T(w.med)) + '</dd>';
    (w.size || []).forEach(function (s) { h += '<dt>' + L('寸法', '尺寸') + '</dt><dd class="mono">' + esc(s) + '</dd>'; });
    w.role.forEach(function (r) { h += '<dt>' + L('担当', '負責') + '</dt><dd>' + esc(T(r).replace(/^(担当|負責)：/, '')) + '</dd>'; });
    h += '<dt>' + L('頁', '頁') + '</dt><dd class="mono">p.' + w.pg + '</dd></dl>';
    var nt = w.notes.concat(w.body || []);
    if (nt.length) h += '<div class="nt">' + nt.map(function (n) { return '<p>' + esc(T(n)) + '</p>'; }).join('') + '</div>';
    if (w.yt) h += '<a class="go" href="https://youtu.be/' + w.yt + '" target="_blank" rel="noopener">' + L('YouTube で見る', '在 YouTube 觀看') + '<span class="mono">↗</span></a><br>';
    h += '<a class="go" href="' + DATA.base + 'book/' + coverQ() + '#p' + parseInt(w.pg, 10) + '">' + L('作品集の頁で見る', '在作品集裡看') + '<span class="mono">p.' + w.pg + ' →</span></a>';   // 選んだ表紙を翻書に（GPT 全站 R1）
    h += '<div class="wnav"><button type="button" data-wstep="-1">← ' + L('前の作品', '上一件') + '</button><button type="button" data-wstep="1">' + L('次の作品', '下一件') + ' →</button></div>';
    $('.info', lb).innerHTML = h;
    // 前後の図を先に読む
    [ci + 1, ci - 1].forEach(function (j) { if (j >= 0 && j < w.imgs.length) { var p = new Image(); p.src = DATA.base + 'img/w/' + w.imgs[j].k + '.webp'; } });
  }
  // 原図が表示よりかなり大きいときだけ「原寸で開く」を出す（スライドの細かい字など）
  function fitOrig() {
    var img = $('.mat img', lb), o = $('.orig', lb);
    if (!img.naturalWidth || !img.clientWidth) return;
    o.hidden = !(img.naturalWidth > img.clientWidth * 1.5);
  }
  window.addEventListener('resize', function () { if (!lb.hidden) fitOrig(); });
  function open(no, i, from) {
    cw = byNo[no]; ci = i || 0; opener = from || null;
    render(); lb.hidden = false; document.body.classList.add('lb-open'); fitOrig();
    $('.close', lb).focus();
    if (history.replaceState) history.replaceState(history.state, '', '#w' + no);
  }
  function close() {
    lb.hidden = true; document.body.classList.remove('lb-open');
    $('.mat img', lb).removeAttribute('src');
    if (history.replaceState) history.replaceState(history.state, '', location.pathname + location.search);
    if (opener) opener.focus();
  }
  function step(d) { var n = W[cw].imgs.length; ci = (ci + d + n) % n; render(); }
  function wstep(d) { cw = (cw + d + W.length) % W.length; ci = 0; render(); if (history.replaceState) history.replaceState(history.state, '', '#w' + W[cw].no); }
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open]');
    if (t) { e.preventDefault(); open(t.dataset.open, parseInt(t.dataset.i || '0', 10), t); return; }
    if (lb.hidden) return;
    if (e.target.closest('.close')) close();
    else if (e.target.closest('.prev')) step(-1);
    else if (e.target.closest('.next')) step(1);
    else if (e.target.closest('[data-wstep]')) wstep(parseInt(e.target.closest('[data-wstep]').dataset.wstep, 10));
    else if (e.target === lb || e.target.classList.contains('stage')) close();
  });
  document.addEventListener('keydown', function (e) {
    if (lb.hidden) return;
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowRight') step(1);
    else if (e.key === 'ArrowLeft') step(-1);
    else if (e.key === 'Tab') {                       // 枠の中で回す
      var f = $$('button:not([hidden]), a[href]', lb).filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      var a = f[0], z = f[f.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    }
  });
  var sx = null;
  lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', function (e) {
    if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(dx) > 50 && W[cw].imgs.length > 1) step(dx < 0 ? 1 : -1);
  });

  /* ---------- 映像：押したときだけ YouTube を読み込む ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-yt]');
    if (!b) return;
    e.preventDefault();
    var f = document.createElement('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + b.dataset.yt + '?autoplay=1&rel=0&modestbranding=1&playsinline=1';
    f.title = b.getAttribute('aria-label') || 'video';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.allowFullscreen = true;
    b.replaceWith(f);
  });

  /* ---------- 表紙を選ぶ（10/27 深夜：本人の希望。翻書の表 1・表 4 が替わる。PDF は替わらない） ---------- */
  var COVS = { online: 'img/pg/c1.webp', print: 'img/pg/c1_print.webp', kin: 'img/pg/c1_kin.webp' };
  var HCOVS = { online: 'img/cover_l.webp', print: 'img/cover_l_print.webp', kin: 'img/cover_l_kin.webp' };
  var cover = 'online';
  try { var c0 = localStorage.getItem('kabi-cover'); if (COVS[c0]) cover = c0; } catch (e) {}
  // 翻書へのリンクに付ける表紙。三款ともいつも明示する（オンライン閲覧版も ?cover=online。別のタブで選んだ表紙が残らないように：GPT 全站 R1）
  function coverQ() { return '?cover=' + cover; }
  function setCover(k, save) {   // 読めている前提で、全部を一度に替える（大きい表紙・下線・身分・下の三款・翻書の表紙・連結・記憶）
    if (!COVS[k]) k = 'online'; cover = k;
    if (save) { try { localStorage.setItem('kabi-cover', k); } catch (e) {} }
    $$('[data-cover]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.cover === k ? 'true' : 'false'); });
    var hb = $('.hero .book'); if (hb) { if (hb.getAttribute('src') !== HCOVS[k]) hb.setAttribute('src', HCOVS[k]); hb.className = 'book cv-' + k; }   // 10/28 下午：首頁の表紙も選んだものに
    hstShow(k);   // 選んだ表紙の身分の一行（GPT R12 C）
    var hp = $('.hero .cvpdf'); if (hp) hp.hidden = k === 'online';    // 首頁の表紙が線上以外のとき、PDF の表紙は線上だと添える（GPT R6）
    var cv = $('.read .obj .cv'); if (cv && cv.getAttribute('src') !== COVS[k]) cv.setAttribute('src', COVS[k]);   // 「作品集を読む」の表紙と名前も同じ回に
    $$('.read .obj [data-cvname]').forEach(function (s) { s.hidden = s.dataset.cvname !== k; });
    // 保存できない環境（プライベート閲覧など）でも翻書に伝わるように、リンクにも付ける
    $$('a[href^="book/"]').forEach(function (a) {                     // 頁への連結（#p106 など）は頁番号を残す（GPT 全站 R1）
      var h = a.getAttribute('href'), i = h.indexOf('#');
      a.setAttribute('href', 'book/' + coverQ() + (i >= 0 ? h.slice(i) : ''));
    });
  }
  function hstShow(key) { $$('.hero [data-hst]').forEach(function (s) { s.hidden = s.dataset.hst !== key; }); }
  // 画像を読んで描ける状態にする（一度読めたものは覚えておく）
  var ready = {};
  function load(src) {
    if (ready[src]) return Promise.resolve();
    var im = new Image(); im.src = src;
    var p = im.decode ? im.decode() : new Promise(function (ok, ng) { im.onload = ok; im.onerror = ng; });
    return p.then(function () { ready[src] = true; });
  }
  // 10/30 GPT R13 必改：押した表紙の大きい画像が読めるまでは、下線・身分・連結などを前のままにする（表紙の絵と名前が食い違わない）。
  // その間は首頁の身分行と、下の三款の押したものに「読み込み中…」（120 ms 以内に読めたら出さない）。読めなかったら前のまま「読み込めませんでした」。
  // 続けて押したら最後のものだけ。いま選んでいるものを押したら待っているものを取り消す
  var reqTok = 0, pendT = 0, ngT = 0, sayT = 0;
  function tx(el) { if (!el) return ''; var c = el.querySelector(root.dataset.lang === 'zh' ? '.zh' : '.ja'); return (c || el).textContent.trim(); }   // いまの言語の文字だけ
  function say(s, t) { var r = $('#cvlive'); if (!r) return; clearTimeout(sayT); r.textContent = ''; sayT = setTimeout(function () { if (t === reqTok) r.textContent = s; }, 60); }   // 一度空にしてから入れる（同じ文でももう一度読まれる）。書く前に、まだ最後の選択か確かめる（GPT R16）
  function sayCover(k, t) { say(tx($('.hero .hsel .hlab')) + '：' + tx($('.hero .hsel [data-cover="' + k + '"]')) + '。' + tx($('.hero [data-hst="' + k + '"]')), t); }
  function clearMarks() { clearTimeout(pendT); clearTimeout(ngT); clearTimeout(sayT); $$('.cvo.ld, .cvo.ng').forEach(function (b) { b.classList.remove('ld', 'ng'); }); hstShow(cover); }
  function request(k, save) {
    if (!COVS[k]) k = 'online';
    var t = ++reqTok; clearMarks();
    var need = [HCOVS[k], COVS[k]];   // 首頁の大きい表紙と「作品集を読む」の表紙（GPT R16 必改：両方読めてから一度に）
    if (k === cover || (ready[need[0]] && ready[need[1]])) { setCover(k, save); if (save) sayCover(k, t); return; }
    pendT = setTimeout(function () { if (t !== reqTok) return; hstShow('ld-' + k); var b = $('.cvo[data-cover="' + k + '"]'); if (b) b.classList.add('ld'); if (save) say(tx($('.hero [data-hst="ld-' + k + '"]')), t); }, 120);
    Promise.all(need.map(load)).then(function () { if (t !== reqTok) return; clearMarks(); setCover(k, save); if (save) sayCover(k, t); },
      function () { if (t !== reqTok) return; clearMarks(); hstShow('ng'); var b = $('.cvo[data-cover="' + k + '"]'); if (b) b.classList.add('ng'); if (save) say(tx($('.hero [data-hst="ng"]')), t);
        ngT = setTimeout(function () { if (t === reqTok) clearMarks(); }, 4000); });
  }
  // 頁が落ち着いてから三款とも先に読んでおく（ほかの二款：大きい表紙 57 KB・34 KB、作品集を読むの表紙 24 KB・19 KB）。選ぶところに触れたときも
  var warmed = false;
  function warm() { if (warmed) return; warmed = true; Object.keys(HCOVS).forEach(function (k) { load(HCOVS[k]).catch(function () {}); load(COVS[k]).catch(function () {}); }); }   // 三款とも（いま出ているものも load() を通して ready に：GPT R16）
  window.addEventListener('load', function () { if (window.requestIdleCallback) requestIdleCallback(warm, { timeout: 3000 }); else setTimeout(warm, 1500); });
  ['pointerenter', 'focusin', 'touchstart'].forEach(function (n) { $$('.hero .hsel, #covers .cv3').forEach(function (g) { g.addEventListener(n, warm, { once: true, passive: true }); }); });
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-cover]'); if (b) request(b.dataset.cover, true); });
  setCover(cover, false);
  function storedCover() { try { var c = localStorage.getItem('kabi-cover'); if (COVS[c]) return c; } catch (e) {} return cover; }
  window.addEventListener('pageshow', function (e) { if (e.persisted) request(storedCover(), false); });   // 上一頁で戻ったとき（bfcache）も、いまの表紙に（GPT R6）
  window.addEventListener('storage', function (e) { if (e.key === 'kabi-cover' && COVS[e.newValue]) request(e.newValue, false); });   // 別の分頁で選んだとき
  /* ---------- 頁の中の移動（10/28 晚 本人「按這個鍵以後 頁面應該是滑到那個位置」「是否要加一個鍵是回到最上面」→ GPT 第十一輪） ----------
     遠いところは全部を流さない（選擇區まで桌機 15,000 px・手機 22,000 px。作品が高速で流れるだけで、途中の図も読み込まれる）。
     目的地の手前（最大 200 px、手機は見えている高さの 30% まで）へ一度に移り、残りを 320 ms で滑らせて止める（だんだん遅く、はね返らない）。
     動きを減らす設定では一度に。ホイール・タッチ・つまみ・キー（Tab も）が入ったら残りの動きはやめ、焦点も動かさない。 */
  function docY(el) { return el.getBoundingClientRect().top + window.pageYOffset; }
  function barH() { var b = $('.bar'); return b ? b.offsetHeight : 56; }
  var glideStop = null;
  function glide(toY, done) {
    if (glideStop) glideStop();
    var max = document.documentElement.scrollHeight - window.innerHeight;
    toY = Math.max(0, Math.min(Math.round(toY), max));
    if (reduce) { window.scrollTo(0, toY); if (done) done(true); return; }
    var lead = Math.min(200, Math.round(window.innerHeight * 0.3)), y0 = window.pageYOffset;
    if (Math.abs(toY - y0) > lead) { window.scrollTo(0, toY + (toY > y0 ? -lead : lead)); y0 = window.pageYOffset; }
    var dist = toY - y0, t0 = null, live = true, D = 320, EV = ['wheel', 'touchstart', 'pointerdown', 'keydown'];
    function off() { EV.forEach(function (n) { window.removeEventListener(n, stop, true); }); glideStop = null; }
    function stop() { if (!live) return; live = false; off(); if (done) done(false); }
    EV.forEach(function (n) { window.addEventListener(n, stop, true); });
    glideStop = stop;
    if (!dist) { live = false; off(); if (done) done(true); return; }
    requestAnimationFrame(function step(ts) {
      if (!live) return;
      if (t0 === null) t0 = ts;
      var k = Math.min(1, (ts - t0) / D);
      window.scrollTo(0, y0 + dist * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(step); else { live = false; off(); if (done) done(true); }
    });
  }
  function focusQuiet(el) { if (!el) return; if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1'); try { el.focus({ preventScroll: true }); } catch (x) { el.focus(); } }
  function plain(e) { return !(e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey); }
  // 履歴：自分で積んだ項目に { 前の項目, 押した連結, 着いた先 } を覚えておく。上一頁なら押した連結へ、下一頁なら着いた先へ焦點を戻す（GPT 第十一輪）
  //   同じ所への移動は積まない（瀏覽器の錨點と同じ）。章の連結など普通の錨點の項目にも印を付けて、どこから来たか分かるようにする
  var navSeq = 0, navRec = {};
  function stId() { var s = history.state; return s && s.kabiNav; }
  function tag() { if (!stId()) { try { history.replaceState({ kabiNav: 'n' + (++navSeq) + '.' + Date.now() }, '', location.href); } catch (x) {} } return stId(); }
  var navCur = tag();
  function navTo(hash, opener, target) {
    if (location.hash === hash) return;
    var from = tag(), id = 'n' + (++navSeq) + '.' + Date.now();
    try { history.pushState({ kabiNav: id }, '', hash); } catch (x) { return; }
    navRec[id] = { from: from, opener: opener, target: target }; navCur = id;
  }
  window.addEventListener('hashchange', function () { navCur = tag(); });
  window.addEventListener('popstate', function () {
    if (glideStop) glideStop();
    var to = stId(), was = navCur, r = navRec[was], f = navRec[to]; navCur = to;
    if (r && r.from === to) { if (document.contains(r.opener)) focusQuiet(r.opener); }          // 上一頁：押した連結に（画面の位置は瀏覽器が戻す）
    else if (f && f.from === was) { if (document.contains(f.target)) focusQuiet(f.target); }    // 下一頁：着いた先に
  });
  // 頁の先頭へ（選擇區の「↑ ページの先頭へ」と上の帯の「黴」）：同じ滑り方で一番上へ。焦點は冒頭（読み上げ名「作品集『黴』の冒頭」）に
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a.totop, .bar a.home'); if (!a || !plain(e)) return;
    var top = $('#top'); e.preventDefault();
    navTo('#top', a, top);
    glide(0, function (ok) { if (ok) focusQuiet(top); });
  });

  /* 函から出す動きは、翻書の頭でだけ（book.js。10/27 深夜（續）本人「一開始是有書殼…按下一頁會有個動畫是從書殼抽出」）。首頁では動かさない */

  /* ---------- 読み込み時 ---------- */
  setLang(root.dataset.lang || 'ja', false);
  onScroll();
  function fromHash() {
    var m = /^#w(\d\d)$/.exec(location.hash);
    if (m && byNo[m[1]] !== undefined) { if (lb.hidden) open(m[1], 0, null); else { cw = byNo[m[1]]; ci = 0; render(); } }
  }
  fromHash();
  window.addEventListener('hashchange', fromHash);
  // 翻書・走進黴裡の「作品一覧へ」（../#toc）から来たとき、焦點は目次へ（GPT R12 必改）：目次の section に tabindex="-1" を付けてあり、
  // 瀏覽器が錨點へ移るときに自分で焦點を置く（10/30：ここで見出しに置いても、そのあと瀏覽器の錨點の処理で外されていた）
  if (reduce) root.style.scrollBehavior = 'auto';

  /* ---------- 捲動で少しずつ出す（10/31 本人：Apple の Mac の頁のように） ----------
     章頭（大字／番号・読み・一行・説明／頁碼）と根の小見出し：下から 30 px・淡入、三つは順に（.rv）。
     作品（図と図説、付いている説明）：同じく下から 30 px・淡入、同じ列は同時（.rv。RVC.unitFade を false にすると、見えたまま 20 px だけの .rvm）。目次・首頁の冒頭・映像・作品集を読む・略歴は動かさない。
     画面の下の端に入ったら始まる（作品・小見出しは自分が 30 px 下がっているので、動く前の位置で判断）。飛んで来たとき（入った時にもう画面の 3/4 より上）と速く捲っているときは待たせずにそのまま。途中から速くなった・飛んだときは、出ている途中のものもすぐ出しきる。
     普通に開いて上から捲って読むときだけ動かす。次のときは最初から何もしない（全部見えたまま）：
       JS がない・減らす設定・IntersectionObserver がない／錨點つきで来た（#toc・#ch-ji・#w22 など）／上一頁・下一頁・再読み込みで来た（瀏覽器が位置を戻す）。
     読み込んだときに少しでも画面に入っているもの・画面より上のものも、そのまま。
     途中で頁の中の連結（目次・章・上の帯・頁の先頭へ）を押した／上一頁・下一頁／bfcache で戻った → 全部すぐ出しきり、この頁ではもう動かさない。
     焦點が来た・押した → そのものだけすぐ出しきる（燈箱を閉じて焦點が作品に戻っても、ほかは止めない）。
     class は rv・rvm・rv-in・rv-now（.read .in などの版面の class と重ならないように） */
  var RVC = { head: '.chead', headKids: '.g, .meta, .pp', headStep: 80, fade: '.chap > .sub-h', unit: '.chap .row > .wk, .mame > *, .cards > .card', unitFade: true, unitStep: 0, cap: 3, off: 30 };
  var navE = null, navT = 'navigate';
  try { navE = performance.getEntriesByType('navigation')[0]; } catch (x) {}
  if (navE && navE.type) navT = navE.type;
  else if (performance.navigation) navT = ['navigate', 'reload', 'back_forward'][performance.navigation.type] || 'navigate';
  if (!reduce && 'IntersectionObserver' in window && !location.hash && navT === 'navigate') {
    var rvOff = false, rvV = 0, rvY = window.pageYOffset, rvT = Date.now();
    window.addEventListener('scroll', function () {   // 捲る速さ（px/ms。続けて捲っている間は少しならす、止まった後は数え直す）
      var y = window.pageYOffset, t = Date.now(), dt = Math.max(8, t - rvT), dy = Math.abs(y - rvY), v = dy / dt;
      rvV = t - rvT > 150 ? v : rvV * 0.5 + v * 0.5; rvY = y; rvT = t;
      if (!rvOff && (rvV > 1.2 || dy > window.innerHeight * 0.5)) {   // 途中から速くなった・飛んだ：出ている途中のもの（章頭の遅れて始まるものも）をすぐ出しきる。まだ入っていないものはそのまま
        var q = document.querySelectorAll('.rv-in:not(.rv-now)'); for (var i = 0; i < q.length; i++) q[i].classList.add('rv-now');
      }
    }, { passive: true });
    var rvFin = function (els) { els.forEach(function (el) { el.classList.add('rv-now'); el.classList.add('rv-in'); }); };
    var rvSeen = function (io, off) {   // off：見張るもの自身が下がっている量（動く前の位置で判断する）
      return function (es) {
        var hit = [];
        es.forEach(function (en) { if (en.isIntersecting) { io().unobserve(en.target); hit.push([en.boundingClientRect.top - off, en.boundingClientRect.left, en.target]); } });
        hit.sort(function (a, b) { return (Math.round(a[0] / 40) - Math.round(b[0] / 40)) || (a[1] - b[1]); });   // 同じ列は左から
        var k = 0, jump = window.innerHeight * 0.75, fast = rvV > 1.2 && Date.now() - rvT < 120;
        hit.forEach(function (h) {
          var t = h[2], els = t._rv || [t];
          if (h[0] < jump || fast) { rvFin(els); return; }   // 飛んで来た・速く捲っている（1.2 px/ms より速い）：待たせずにそのまま
          if (!t._rv && RVC.unitStep) t.style.setProperty('--rvd', (Math.min(k++, RVC.cap) * RVC.unitStep) + 'ms');
          els.forEach(function (el) { el.classList.add('rv-in'); });   // 章頭：三つの間隔は先に付けてある
        });
      };
    };
    var rvIOg = new IntersectionObserver(rvSeen(function () { return rvIOg; }, 0), { rootMargin: '0px' });
    var rvIOu = new IntersectionObserver(rvSeen(function () { return rvIOu; }, RVC.off), { rootMargin: '0px 0px ' + RVC.off + 'px 0px' });
    var vh0 = window.innerHeight;
    var below = function (el) { return !el.closest('.lb') && el.getBoundingClientRect().top >= vh0; };   // 画面に入っている・上：そのまま（下の端に少し見えているものも）
    $$(RVC.head).forEach(function (g) {
      if (g._rv || !below(g)) return;
      var kids = $$(RVC.headKids, g).filter(function (k) { return !k._rvd; });
      if (!kids.length) return;
      kids.forEach(function (k, i) { k._rvd = 1; k.classList.add('rv'); k.style.setProperty('--rvd', (Math.min(i, RVC.cap) * RVC.headStep) + 'ms'); });
      g._rv = kids; rvIOg.observe(g);
    });
    $$(RVC.fade).forEach(function (el) { if (el._rvd || !below(el)) return; el._rvd = 1; el.classList.add('rv'); rvIOu.observe(el); });
    $$(RVC.unit).forEach(function (el) { if (el._rvd || !below(el)) return; el._rvd = 1; el.classList.add(RVC.unitFade ? 'rv' : 'rvm'); rvIOu.observe(el); });
    var rvAll = function () {   // 全部すぐ出しきる（まだのもの・遅れて始まるのを待っているもの・出ている途中のものも）。以後この頁では動かさない
      if (rvOff) return; rvOff = true; rvIOg.disconnect(); rvIOu.disconnect();
      rvFin($$('.rv, .rvm'));
    };
    var rvOne = function (e) {   // 焦點・押したもの：そのものだけ
      var u = e.target && e.target.closest && e.target.closest('.rv, .rvm'); if (!u || u.classList.contains('rv-now')) return;
      var g = u.closest(RVC.head);
      if (g && g._rv) { rvIOg.unobserve(g); rvFin(g._rv); } else { rvIOu.unobserve(u); rvFin([u]); }
    };
    document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('a[href^="#"]')) rvAll(); }, true);   // 瀏覽器が飛ぶ前に（同じ錨點をもう一度押したときも）
    window.addEventListener('hashchange', rvAll);
    window.addEventListener('popstate', rvAll);
    window.addEventListener('pageshow', function (e) { if (e.persisted) rvAll(); });
    document.addEventListener('focusin', rvOne);   // 透明なところに焦點を置かない
    document.addEventListener('pointerdown', rvOne, true);
    root.classList.add('rv-on');
  }
})();
