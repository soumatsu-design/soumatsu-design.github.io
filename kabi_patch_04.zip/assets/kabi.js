/* 黴　かび — 黴のなかへ：下へ進むと、章ごとに黴が育つ（スクロールは止めない）。10/27 晚：章扉（中央の大きな字）→ 作品と説明の二段 */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var secs = $$('.k-sec'), idx = $$('.k-idx a');
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var still = false;
  try { still = localStorage.getItem('kabi-still') === '1'; } catch (e) {}
  if (mq && mq.matches) still = true;

  function setLang(l) {
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
    if (typeof fit === 'function') fit();
  }
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-set-lang]'); if (b) setLang(b.dataset.setLang); });

  function setStill(s) {
    still = s; document.body.classList.toggle('still', s);
    var b = $('.k-still'); b.setAttribute('aria-pressed', s ? 'true' : 'false');
    try { localStorage.setItem('kabi-still', s ? '1' : '0'); } catch (e) {}
    frame();
  }
  $('.k-still').addEventListener('click', function () { setStill(!still); });

  var vh = window.innerHeight;
  function frame() {
    vh = window.innerHeight;
    var cur = 0;
    secs.forEach(function (s, i) {
      var r = s.getBoundingClientRect();
      var span = Math.max(1, r.height - vh);
      var p = Math.min(1, Math.max(0, -r.top / span));
      if (r.top < vh * .5) cur = i;
      // 章は二段：p 0–.34 で黴が育つ（章扉）、.28–.44 で字が左へ寄り作品と説明が出る（GPT：黴が育ちきるのを待たせない）。止めているときは途中を飛ばす
      var g, t;
      if (s.classList.contains('k-intro')) { g = still ? 1 : p; t = 0; }
      else {
        g = still ? 1 : Math.min(1, p / .34);
        var u = Math.min(1, Math.max(0, (p - .28) / .16));
        t = still ? (p > .36 ? 1 : 0) : u * u * (3 - 2 * u);
      }
      s.style.setProperty('--p', p.toFixed(4));
      s.style.setProperty('--g', g.toFixed(4));
      s.style.setProperty('--t', t.toFixed(4));
      s.classList.toggle('b2', t > .02);
      if (s.classList.contains('k-intro')) {
        var lines = $$('.k-line', s), n = lines.length;
        lines.forEach(function (ln, j) { ln.classList.toggle('on', still || p * (n + 1.2) > j + .3); });
      }
    });
    idx.forEach(function (a, i) { a.classList.toggle('on', i === cur); if (i === cur) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current'); });
  }
  // 10/27 深夜：背の低い手機（iPhone SE の 375×667 など）で、作品の図説が下の章の説明に重なっていた → 手機で入りきらないときだけ、
  //   作品を「左上の字の下」から「説明の上」までに収める（図を少し小さく）。入るときは CSS のまま（390×844 などは変わらない）
  function fit() {
    var vw = window.innerWidth, h = window.innerHeight;
    var land = vw > h && h <= 520, mob = vw <= 760 && !land;          // 横向きの低い画面は CSS の @media (orientation:landscape) and (max-height:520px) と同じ条件
    secs.forEach(function (s) {
      if (s.classList.contains('k-intro')) return;
      var w = $('.k-work', s), im = $('img', w), cap = $('figcaption', w), tx = $('.k-txt', s);
      if (!w || !im || !tx) return;
      w.style.top = w.style.transform = ''; im.style.width = im.style.maxWidth = im.style.maxHeight = '';
      s.style.removeProperty('--gmax');
      if (land) {
        // 字：上の帯（50px）から説明の上まで。作品：上の帯の下から画面の下まで、図説を残して図を縮める
        var txTop = h - h * .05 - tx.offsetHeight;
        s.style.setProperty('--gmax', Math.max(56, txTop - 50 - 10).toFixed(0) + 'px');
        var capH0 = cap ? cap.offsetHeight + 10 : 0;
        im.style.maxHeight = Math.max(90, h - 56 - 18 - capH0).toFixed(0) + 'px';
        return;
      }
      if (!mob) return;
      var top0 = h * .11 + vw * .26 + 12, bot0 = h * .95 - tx.offsetHeight - 12;
      var H = w.offsetHeight, defTop = h * .5 - .46 * H;
      if (defTop >= top0 && defTop + H <= bot0) return;
      var capH = cap ? cap.offsetHeight + 10 : 0;                     // 図説の幅は変えない（行数が増えないように）、図だけ縮める
      im.style.width = 'auto'; im.style.maxWidth = '100%'; im.style.maxHeight = Math.max(90, bot0 - top0 - capH).toFixed(0) + 'px';
      w.style.top = top0.toFixed(1) + 'px';
      w.style.transform = w.classList.contains('wide') ? 'none' : 'translateX(-50%)';
    });
  }
  var tick = false;
  window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(function () { tick = false; frame(); }); } }, { passive: true });
  window.addEventListener('resize', function () { fit(); frame(); });
  window.addEventListener('load', fit);
  idx.forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var t = document.getElementById(a.getAttribute('href').slice(1));
      var y = t.getBoundingClientRect().top + window.pageYOffset + (t.classList.contains('k-intro') ? 0 : vh * .35);
      window.scrollTo({ top: y, behavior: still ? 'auto' : 'smooth' });
    });
  });
  // キーボードで章扉のうちに作品・説明のリンクへ入ったら、その章の二段目まで送る（作品が大きな字に重ならないように）
  document.addEventListener('focusin', function (e) {
    var s = e.target.closest ? e.target.closest('.k-sec') : null;
    if (!s || s.classList.contains('k-intro') || s.classList.contains('b2') || !e.target.closest('.k-work, .k-txt')) return;
    var r = s.getBoundingClientRect();
    window.scrollTo({ top: r.top + window.pageYOffset + Math.max(1, r.height - vh) * .6, behavior: 'auto' });
  });
  setLang(root.dataset.lang || 'ja');
  setStill(still);
})();
