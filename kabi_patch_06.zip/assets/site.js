/* 黴　かび — 首頁：言語、上の帯、大きく見る、映像 */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 言語：切り替えても読んでいた場所から動かない ---------- */
  function setLang(l, keep) {
    var anchor = null, top = 0;
    if (keep) {
      var cands = $$('h2, h3, .wk, .chead, .toc li, .film, .card, .about li, .foot p');
      for (var i = 0; i < cands.length; i++) {
        var r = cands[i].getBoundingClientRect();
        if (r.bottom > 70) { anchor = cands[i]; top = r.top; break; }
      }
    }
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
    if (anchor) window.scrollBy(0, anchor.getBoundingClientRect().top - top);
    if (lb && !lb.hidden) render();
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-set-lang]');
    if (b) { e.preventDefault(); setLang(b.dataset.setLang, true); }
  });

  /* ---------- 上の帯：冒頭を過ぎたら出す。今の章を示す。下の地の色に合わせる ---------- */
  var bar = $('.bar'), hero = $('.hero');
  var chaps = $$('[data-ch]'), links = $$('.bar nav a');
  function onScroll() {
    if (!bar) return;
    var hb = hero.getBoundingClientRect().bottom;
    bar.classList.toggle('on', hb < 40);
    var cur = null;
    for (var i = 0; i < chaps.length; i++) { if (chaps[i].getBoundingClientRect().top < 120) cur = chaps[i].dataset.ch; }
    links.forEach(function (a) { a.classList.toggle('on', a.dataset.go === cur); });
    var under = document.elementFromPoint(window.innerWidth / 2, 70);
    var sec = under && under.closest('.s-paper, .s-night');
    if (sec) { bar.classList.toggle('s-paper', sec.classList.contains('s-paper')); bar.classList.toggle('s-night', !sec.classList.contains('s-paper')); }
  }
  var tick = false;
  window.addEventListener('scroll', function () { if (!tick) { tick = true; requestAnimationFrame(function () { tick = false; onScroll(); }); } }, { passive: true });
  window.addEventListener('resize', onScroll);

  /* ---------- 大きく見る ---------- */
  var DATA = JSON.parse($('#works-data').textContent);
  var W = DATA.works, byNo = {};
  W.forEach(function (w, i) { byNo[w.no] = i; });
  var lb = $('#lb'), cw = 0, ci = 0, opener = null;
  function T(o) { return o ? (root.dataset.lang === 'zh' ? (o.zh || o.ja) : (o.ja || o.zh)) : ''; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function L(ja, zh) { return root.dataset.lang === 'zh' ? zh : ja; }
  function render() {
    var w = W[cw], im = w.imgs[ci];
    var img = $('.mat img', lb);
    var o = $('.orig', lb); o.hidden = true;
    img.onload = fitOrig;
    img.src = DATA.base + 'img/w/' + im.k + '.webp';
    img.width = im.w; img.height = im.h; o.href = img.src;
    if (img.complete && img.naturalWidth) fitOrig();
    $('.mat', lb).classList.toggle('lt', !!im.lt);
    img.alt = w.title + (w.imgs.length > 1 ? '（' + (ci + 1) + '／' + w.imgs.length + '）' : '');
    $('.cnt', lb).textContent = w.imgs.length > 1 ? (ci + 1) + ' / ' + w.imgs.length : '';
    $('.ic', lb).textContent = im.c ? T(im.c) : '';
    $('.prev', lb).hidden = $('.next', lb).hidden = w.imgs.length < 2;
    var h = '<div class="no">' + w.no + '</div><h2 id="lb-t">' + esc(w.title) + (w.rb && root.dataset.lang === 'ja' ? '<span class="rb">' + esc(w.rb) + '</span>' : '') + '</h2><dl>';
    if (w.year) h += '<dt>' + L('年', '年份') + '</dt><dd class="mono">' + esc(w.year) + '</dd>';
    if (w.med && (w.med.ja || w.med.zh)) h += '<dt>' + L('技法', '媒材') + '</dt><dd>' + esc(T(w.med)) + '</dd>';
    (w.size || []).forEach(function (s) { h += '<dt>' + L('寸法', '尺寸') + '</dt><dd class="mono">' + esc(s) + '</dd>'; });
    w.role.forEach(function (r) { h += '<dt>' + L('担当', '負責') + '</dt><dd>' + esc(T(r).replace(/^(担当|負責)：/, '')) + '</dd>'; });
    h += '<dt>' + L('頁', '頁') + '</dt><dd class="mono">p.' + w.pg + '</dd></dl>';
    var nt = w.notes.concat(w.body || []);
    if (nt.length) h += '<div class="nt">' + nt.map(function (n) { return '<p>' + esc(T(n)) + '</p>'; }).join('') + '</div>';
    if (w.yt) h += '<a class="go" href="https://youtu.be/' + w.yt + '" target="_blank" rel="noopener">' + L('YouTube で見る', '在 YouTube 觀看') + '<span class="mono">↗</span></a><br>';
    h += '<a class="go" href="' + DATA.base + 'book/' + coverQ() + '#p' + parseInt(w.pg, 10) + '">' + L('作品集の頁で見る', '在作品集裡看') + '<span class="mono">p.' + w.pg + ' →</span></a>';   // 選んだ表紙を翻書に（GPT 全站 R1）
    h += '<div class="wnav"><button type="button" data-wstep="-1">← ' + L('前の作品', '上一件') + '</button><button type="button" data-wstep="1">' + L('次の作品', '下一件') + ' →</button></div>';
    $('.info', lb).innerHTML = h;
    // 前後の図を先に読む
    [ci + 1, ci - 1].forEach(function (j) { if (j >= 0 && j < w.imgs.length) { var p = new Image(); p.src = DATA.base + 'img/w/' + w.imgs[j].k + '.webp'; } });
  }
  // 原図が表示よりかなり大きいときだけ「原寸で開く」を出す（スライドの細かい字など）
  function fitOrig() {
    var img = $('.mat img', lb), o = $('.orig', lb);
    if (!img.naturalWidth || !img.clientWidth) return;
    o.hidden = !(img.naturalWidth > img.clientWidth * 1.5);
  }
  window.addEventListener('resize', function () { if (!lb.hidden) fitOrig(); });
  function open(no, i, from) {
    cw = byNo[no]; ci = i || 0; opener = from || null;
    render(); lb.hidden = false; document.body.classList.add('lb-open'); fitOrig();
    $('.close', lb).focus();
    if (history.replaceState) history.replaceState(null, '', '#w' + no);
  }
  function close() {
    lb.hidden = true; document.body.classList.remove('lb-open');
    $('.mat img', lb).removeAttribute('src');
    if (history.replaceState) history.replaceState(null, '', location.pathname + location.search);
    if (opener) opener.focus();
  }
  function step(d) { var n = W[cw].imgs.length; ci = (ci + d + n) % n; render(); }
  function wstep(d) { cw = (cw + d + W.length) % W.length; ci = 0; render(); if (history.replaceState) history.replaceState(null, '', '#w' + W[cw].no); }
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open]');
    if (t) { e.preventDefault(); open(t.dataset.open, parseInt(t.dataset.i || '0', 10), t); return; }
    if (lb.hidden) return;
    if (e.target.closest('.close')) close();
    else if (e.target.closest('.prev')) step(-1);
    else if (e.target.closest('.next')) step(1);
    else if (e.target.closest('[data-wstep]')) wstep(parseInt(e.target.closest('[data-wstep]').dataset.wstep, 10));
    else if (e.target === lb || e.target.classList.contains('stage')) close();
  });
  document.addEventListener('keydown', function (e) {
    if (lb.hidden) return;
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowRight') step(1);
    else if (e.key === 'ArrowLeft') step(-1);
    else if (e.key === 'Tab') {                       // 枠の中で回す
      var f = $$('button:not([hidden]), a[href]', lb).filter(function (x) { return x.offsetParent !== null; });
      if (!f.length) return;
      var a = f[0], z = f[f.length - 1];
      if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
    }
  });
  var sx = null;
  lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', function (e) {
    if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(dx) > 50 && W[cw].imgs.length > 1) step(dx < 0 ? 1 : -1);
  });

  /* ---------- 映像：押したときだけ YouTube を読み込む ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-yt]');
    if (!b) return;
    e.preventDefault();
    var f = document.createElement('iframe');
    f.src = 'https://www.youtube-nocookie.com/embed/' + b.dataset.yt + '?autoplay=1&rel=0&modestbranding=1&playsinline=1';
    f.title = b.getAttribute('aria-label') || 'video';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    f.allowFullscreen = true;
    b.replaceWith(f);
  });

  /* ---------- 表紙を選ぶ（10/27 深夜：本人の希望。翻書の表 1・表 4 が替わる。PDF は替わらない） ---------- */
  var COVS = { online: 'img/pg/c1.webp', print: 'img/pg/c1_print.webp', kin: 'img/pg/c1_kin.webp' };
  var HCOVS = { online: 'img/cover_l.webp', print: 'img/cover_l_print.webp', kin: 'img/cover_l_kin.webp' };
  var cover = 'online';
  try { var c0 = localStorage.getItem('kabi-cover'); if (COVS[c0]) cover = c0; } catch (e) {}
  // 翻書へのリンクに付ける表紙。三款ともいつも明示する（オンライン閲覧版も ?cover=online。別のタブで選んだ表紙が残らないように：GPT 全站 R1）
  function coverQ() { return '?cover=' + cover; }
  function setCover(k, save) {
    if (!COVS[k]) k = 'online'; cover = k;
    if (save) { try { localStorage.setItem('kabi-cover', k); } catch (e) {} }
    $$('[data-cover]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.cover === k ? 'true' : 'false'); });
    var cv = $('.read .obj .cv'); if (cv && cv.getAttribute('src') !== COVS[k]) cv.setAttribute('src', COVS[k]);
    $$('.read .obj [data-cvname]').forEach(function (s) { s.hidden = s.dataset.cvname !== k; });   // 表紙の下の名前
    var hb = $('.hero .book'); if (hb && hb.getAttribute('src') !== HCOVS[k]) { hb.setAttribute('src', HCOVS[k]); }   // 10/28 下午：首頁の表紙も選んだものに（「翻閱」で開く表紙と同じ）
    if (hb) hb.className = 'book cv-' + k;
    $$('.hero [data-hcvname]').forEach(function (s) { s.hidden = s.dataset.hcvname !== k; });
    var hp = $('.hero .cvpdf'); if (hp) hp.hidden = k === 'online';    // 首頁の表紙が線上以外のとき、PDF の表紙は線上だと添える（GPT R6）
    // 保存できない環境（プライベート閲覧など）でも翻書に伝わるように、リンクにも付ける
    $$('a[href^="book/"]').forEach(function (a) {                     // 頁への連結（#p106 など）は頁番号を残す（GPT 全站 R1）
      var h = a.getAttribute('href'), i = h.indexOf('#');
      a.setAttribute('href', 'book/' + coverQ() + (i >= 0 ? h.slice(i) : ''));
    });
  }
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-cover]'); if (b) setCover(b.dataset.cover, true); });
  setCover(cover, false);
  function storedCover() { try { var c = localStorage.getItem('kabi-cover'); if (COVS[c]) return c; } catch (e) {} return cover; }
  window.addEventListener('pageshow', function (e) { if (e.persisted) setCover(storedCover(), false); });   // 上一頁で戻ったとき（bfcache）も、いまの表紙に（GPT R6）
  window.addEventListener('storage', function (e) { if (e.key === 'kabi-cover' && COVS[e.newValue]) setCover(e.newValue, false); });   // 別の分頁で選んだとき
  document.addEventListener('click', function (e) {                   // 首頁の「表紙を選ぶ」：選擇區へ。焦點もそこへ（GPT R6）
    var a = e.target.closest('.hero .pick'); if (!a) return;
    var h = $('#covers-h'); if (!h) return;
    setTimeout(function () { h.setAttribute('tabindex', '-1'); try { h.focus({ preventScroll: true }); } catch (x) { h.focus(); } }, 0);
  });

  /* 函から出す動きは、翻書の頭でだけ（book.js。10/27 深夜（續）本人「一開始是有書殼…按下一頁會有個動畫是從書殼抽出」）。首頁では動かさない */

  /* ---------- 読み込み時 ---------- */
  setLang(root.dataset.lang || 'ja', false);
  onScroll();
  function fromHash() {
    var m = /^#w(\d\d)$/.exec(location.hash);
    if (m && byNo[m[1]] !== undefined) { if (lb.hidden) open(m[1], 0, null); else { cw = byNo[m[1]]; ci = 0; render(); } }
  }
  fromHash();
  window.addEventListener('hashchange', fromHash);
  if (reduce) root.style.scrollBehavior = 'auto';
})();
