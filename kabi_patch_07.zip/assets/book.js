/* 黴　かび — 作品集を読む（StPageFlip、MIT） */
(function () {
  'use strict';
  var root = document.documentElement;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  var N = 112, LAST = N + 3;                 // 0＝表 1、1＝見返し、2..113＝p.001..112、114＝見返し、115＝表 4
  var pages = $$('#book .page');
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function L(ja, zh) { return root.dataset.lang === 'zh' ? zh : ja; }

  /* 表紙（10/27 深夜：首頁「表紙を選ぶ」で選んだもの。?cover= が先、なければ前に選んだもの、なければオンライン閲覧版）。
     表 1・表 4 を替える。印刷版の表紙のときは p.111 も「表紙の食い跡」を書いた頁に。PDF は替わらない */
  var COV = { online: ['c1', 'c4', null], print: ['c1_print', 'c4_print', 'p111_print'], kin: ['c1_kin', 'c4_kin', null] };
  var CNAME = { print: ['表紙：印刷版', '封面：紙本版'], kin: ['表紙：菌落', '封面：菌落'] };   // 短く（GPT 全站 R1）。10/28 晚 本人：名前は「菌落」だけ
  var cover = 'online';
  (function () {
    var q = /[?&]cover=([a-z]+)/.exec(location.search);
    if (q && COV[q[1]]) { cover = q[1]; try { localStorage.setItem('kabi-cover', cover); } catch (e) {} return; }
    try { var s = localStorage.getItem('kabi-cover'); if (COV[s]) cover = s; } catch (e) {}
  })();
  (function () {
    var c = COV[cover];
    function set(i, n) { var im = pages[i] && pages[i].querySelector('img'); if (im && n) im.dataset.src = '../img/pg/' + n + '.webp'; }
    set(0, c[0]); set(pages.length - 1, c[1]); if (c[2]) set(112, c[2]);      // 0＝表 1、112＝p.111、最後＝表 4
  })();
  var CSHORT = { print: ['印刷版', '紙本版'], kin: ['菌落', '菌落'] };
  function cvTag() { var n = CSHORT[cover]; return n ? '（' + L(n[0], n[1]) + '）' : ''; }   // 手機では見出しが隠れるので、頁の番号のところにも
  function cvName() {   // 10/28：幅 359px 以下では短い名に（10/28 晚から菌落は長短とも「菌落」）。「表紙：」は読み上げだけに残す（320px 幅で言語の切替が画面の外へ出ていた）
    var s = $('.cvn'); if (s) {
      var n = CNAME[cover], m = CSHORT[cover]; s.hidden = !n; s.textContent = '';
      if (n) {
        var a = document.createElement('span'); a.className = 'cl'; a.textContent = L(n[0], n[1]);
        var c = document.createElement('span'); c.className = 'cs';
        var v = document.createElement('span'); v.className = 'vh'; v.textContent = L('表紙：', '封面：');
        c.appendChild(v); c.appendChild(document.createTextNode(L(m[0], m[1]))); s.appendChild(a); s.appendChild(c);
      }
      document.body.classList.toggle('cvx', !!n);
    }
    $$('.cvpdf').forEach(function (x) { x.hidden = cover === 'online'; });     // PDF はオンライン閲覧版の表紙（ほかの表紙を選んだときだけ書く）
    $$('.cvkin').forEach(function (x) { x.hidden = cover !== 'kin'; });       // 10/28 晚：名前を「菌落」だけにしたので、未印刷は註で（菌落を選んだときだけ。GPT R11 C）
  }

  function setLang(l) {
    root.dataset.lang = l; root.lang = l === 'zh' ? 'zh-Hant' : 'ja';
    try { localStorage.setItem('kabi-lang', l); } catch (e) {}
    $$('[data-set-lang]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.setLang === l ? 'true' : 'false'); });
    document.title = l === 'zh' ? document.body.dataset.titleZh : document.body.dataset.titleJa;
    cvName();
    label();
  }
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-set-lang]'); if (b) setLang(b.dataset.setLang); });

  /* 頁の画像：いまの頁のまわりから順に読む */
  var loaded = {};
  function load(i) {
    if (typeof i !== 'number' || i < 0 || i > LAST || loaded[i]) return; loaded[i] = 1;
    var im = pages[i].querySelector('img'); if (im && im.dataset.src) im.src = im.dataset.src;
  }
  function near(i) { for (var d = -3; d <= 6; d++) load(i + d); }
  var queue = null;
  function rest(from) {
    var order = []; for (var d = 7; d <= LAST; d++) { order.push(from + d); order.push(from - d); }
    order = order.filter(function (x) { return x >= 0 && x <= LAST && !loaded[x]; });
    clearInterval(queue);
    queue = setInterval(function () { if (!order.length) { clearInterval(queue); return; } load(order.shift()); load(order.shift()); }, 350);
  }

  /* 本の大きさ：画面の高さに合わせる */
  var stage = $('.bk-stage'), book = $('#book');
  var narrow = window.innerWidth < 720;
  var pf = new St.PageFlip(book, {
    width: 450, height: 640, size: 'stretch', minWidth: 200, maxWidth: 1000, minHeight: 284, maxHeight: 1422,
    showCover: true, usePortrait: true, autoSize: true, mobileScrollSupport: false, maxShadowOpacity: .45,
    flippingTime: reduce ? 1 : 700, drawShadow: !reduce, swipeDistance: 24, showPageCorners: !narrow
  });
  function fit() {
    var h = stage.clientHeight - 24, w = stage.clientWidth - 24;
    var portrait = pf.getOrientation && pf.getOrientation() === 'portrait';
    var ratio = portrait ? 450 / 640 : 900 / 640;
    book.style.setProperty('width', Math.min(w, h * ratio) + 'px', 'important');
  }

  var start = 0, m = /^#p(\d{1,3})$/.exec(location.hash);
  if (m) { var p = Math.max(1, Math.min(N, parseInt(m[1], 10))); start = p + 1; }
  near(start);

  /* 函（10/27 深夜：本人「一開始是有書殼…從書殼抽出，然後可以開始翻頁」）。10/28 GPT 全站 R2 の設計：
     頁の番号なしで開いた最初の一回（同じセッションで一度）だけ、表紙の上に函をかぶせて始める。函は見るだけの層（押せない、焦点に入らない）。
     表紙と函の画像が出そろったら、少し見せてから（HOLD）函が右へ退く（書の背の側が開口＝書は左へ出る）。
     どの操作（押す、触れる、キー、ホイール）でも函はその場で消え、その操作はそのまま翻書に届く（最初の「→」でちゃんと一頁めくれる）。
     動きを減らす設定では函を出さない。函の身分は「函「朱の箱」：デザイン案」の一行（表紙のあいだずっと）と目次の説明で */
  var cs = $('.bk-case'), ci = $('.bk-caseinfo'), HOLD = 600, autoT = null, lateT = null, casing = false, caseOk = false;
  (function () {
    var seen = false; try { seen = sessionStorage.getItem('kabi-cased') === '1'; } catch (e) {}
    casing = !start && !!cs && !seen && !reduce;
  })();
  var placeTries = 0, infoTries = 0;
  function placeCase() {                                              // 函は書より少し大きく（約 3%）、ただし舞台からはみ出さない（端を切らない）
    if (!casing || !caseOk) return;
    var r = pages[0].getBoundingClientRect(), sr = stage.getBoundingClientRect();
    if (!r.width) { if (placeTries++ < 60) requestAnimationFrame(placeCase); return; }   // 10/28：翻書がまだ頁を並べていないときは次の描画でもう一度
    var w = Math.max(r.width, Math.min(r.width * 1.03, sr.width - 4, (sr.height - 4) * 900 / 1292)), h = w * 1292 / 900;
    cs.style.width = w + 'px'; cs.style.height = h + 'px';
    cs.style.left = (r.left - sr.left - (w - r.width) / 2) + 'px';
    cs.style.top = (r.top - sr.top + (r.height - h) / 2) + 'px';
    var was = cs.hidden; cs.hidden = false;
    if (was && !shown) confirmShown();
  }
  var shown = false, coverReady = false;
  function confirmShown() {                                           // 10/28 GPT R6：rAF 一回は描画の前。二回目でまだ見えていて、分頁も表示中なら「表示された」＝ここで初めて「看過」を記録
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      if (!casing || !cs || cs.hidden || shown || document.visibilityState !== 'visible') return;
      shown = true; try { sessionStorage.setItem('kabi-cased', '1'); } catch (e) {}
      startHold();
    }); });
  }
  function startHold() {                                              // 停留（HOLD）は、函が表示され、表紙も出そろってから数える
    if (!casing || !shown || !coverReady || autoT) return;
    clearTimeout(lateT); autoT = setTimeout(function () { uncase(false); }, HOLD);
  }
  function placeInfo() {                                              // 函の一行：表紙のあいだだけ。書の下に余白があれば下、なければ書の左（見開きの左半分）、それもなければ表紙の下端に重ねる
    if (!ci) return;
    var show = pf.getCurrentPageIndex() === 0; ci.hidden = !show; if (!show) return;
    var r = pages[0].getBoundingClientRect(), sr = stage.getBoundingClientRect(); if (!r.width) { ci.hidden = true; if (infoTries++ < 60) requestAnimationFrame(placeInfo); return; }
    ci.className = 'bk-caseinfo'; ci.style.cssText = '';
    var over = r.height * .02 + 6;                                    // 函が表紙より下へ出るぶん、一行を下げる（函と重ならない）
    var need = ci.offsetWidth;                                        // 一行のままの幅（CSS で折り返さない）
    if (sr.bottom - r.bottom >= over + 26) { ci.style.left = (r.left - sr.left) + 'px'; ci.style.width = r.width + 'px'; ci.style.top = (r.bottom - sr.top + over) + 'px'; }
    else if (r.left - sr.left >= need + 36) { ci.classList.add('side'); ci.style.right = (sr.right - r.left + 18) + 'px'; ci.style.bottom = (sr.bottom - r.bottom) + 'px'; }
    else { ci.classList.add('over'); ci.style.left = (r.left - sr.left) + 'px'; ci.style.width = r.width + 'px'; ci.style.top = (r.bottom - sr.top - 34) + 'px'; }
  }
  var hideT = null;
  function uncase(now) {                                              // now＝その場で消す（止まっているときも、退いている途中でも。10/28 GPT 全站 R3 の必改）
    if (casing) {
      casing = false; clearTimeout(autoT); clearTimeout(lateT); document.body.classList.remove('casing');   // 「看過」はここでは書かない（表示が確かめられたときだけ：confirmShown）
    }
    if (!cs || cs.hidden) return;
    if (now) { clearTimeout(hideT); cs.hidden = true; }
    else if (!cs.classList.contains('off')) { cs.classList.add('off'); hideT = setTimeout(function () { cs.hidden = true; }, 520); }
  }
  function armCase() {                                                // 函が読めたらすぐ表紙の上へ（表紙より先に見える）。表紙も出そろってから数える。読めない・遅すぎるときは函をやめる
    if (!casing) return;
    var im0 = cs.querySelector('img'), cv = pages[0].querySelector('img');
    function bad() { uncase(true); }
    function coverIn() { coverReady = true; startHold(); }
    function caseIn() { caseOk = true; placeCase(); }
    lateT = setTimeout(function () { uncase(false); }, 3000);          // 3 秒で表示と表紙がそろわなければ、函で待たせない（表示前にやめたら「看過」にしない。遅れて届いた画像で函を出し直さない：casing が false）
    if (!im0) { bad(); return; }
    if (im0.complete) { if (im0.naturalWidth) caseIn(); else { bad(); return; } }
    else { im0.addEventListener('load', caseIn, { once: true }); im0.addEventListener('error', bad, { once: true }); }
    if (!cv || (cv.complete && cv.naturalWidth)) coverIn();
    else if (cv.complete) bad();
    else { cv.addEventListener('load', coverIn, { once: true }); cv.addEventListener('error', bad, { once: true }); }
  }
  if (casing) {
    document.body.classList.add('casing');
    ['pointerdown', 'touchstart', 'keydown', 'wheel'].forEach(function (ev) {   // どの操作でも、その場で函を消す（操作そのものは止めない）
      document.addEventListener(ev, function () { if (casing || !cs.hidden) uncase(true); }, { capture: true, passive: true });
    });
  }
  var ro = window.ResizeObserver ? new ResizeObserver(function () { placeCase(); placeInfo(); }) : null;   // 書の実際の大きさに合わせる

  pf.on('init', function () { fit(); label(); rest(start); placeCase(); placeInfo(); armCase(); if (ro) ro.observe(book); });
  pf.on('changeOrientation', function () { fit(); label(); placeCase(); placeInfo(); });
  pf.on('flip', function (e) { near(e.data); rest(e.data); label(); placeInfo(); });
  pf.loadFromHTML(pages);
  if (start) pf.turnToPage(start);
  window.addEventListener('resize', function () { fit(); placeCase(); placeInfo(); });

  function bookPage(i) { return (i >= 2 && i <= N + 1) ? i - 1 : null; }
  function name(i) {
    if (i === 0) return L('表紙', '封面') + cvTag(); if (i === LAST) return L('裏表紙', '封底') + cvTag();
    if (i === 1 || i === LAST - 1) return L('見返し', '蝴蝶頁');
    return 'p.' + ('00' + bookPage(i)).slice(-3);
  }
  function label() {
    var i = pf.getCurrentPageIndex(), t, hash = '';
    if (pf.getOrientation() === 'portrait' || i === 0 || i === LAST) { t = name(i); if (bookPage(i)) hash = '#p' + bookPage(i); }
    else {
      var a = i % 2 === 1 ? i : i - 1, b = a + 1;
      var pa = bookPage(a), pb = bookPage(b);
      t = pa && pb ? 'p.' + ('00' + pa).slice(-3) + '–' + ('00' + pb).slice(-3) : name(a) + '　' + name(b);
      if (pa || pb) hash = '#p' + (pa || pb);
    }
    $('.pgno').textContent = t + '　／　' + N;
    if (history.replaceState) history.replaceState(null, '', hash ? hash : location.pathname + location.search);
    $('.prev').disabled = i === 0; $('.next').disabled = i >= LAST - (pf.getOrientation() === 'portrait' ? 0 : 1);
  }

  /* 操作 */
  $('.prev').addEventListener('click', function () { pf.flipPrev(); });
  $('.next').addEventListener('click', function () { pf.flipNext(); });
  document.addEventListener('keydown', function (e) {
    if (e.target.closest && e.target.closest('input, textarea')) return;
    var z = document.querySelector('.bk-zoom'); if (z && !z.hidden) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); pf.flipNext(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); pf.flipPrev(); }
    else if (e.key === 'Escape') toggleToc(false);
  });
  var toc = $('.bk-toc'), tb = $('.toc-btn');
  function toggleToc(on) {
    on = on === undefined ? toc.hidden : on; toc.hidden = !on; tb.setAttribute('aria-expanded', on ? 'true' : 'false');
    if (on) { var f = toc.querySelector('a'); if (f) f.focus(); }
  }
  tb.addEventListener('click', function () { toggleToc(); });
  toc.addEventListener('click', function (e) {
    var a = e.target.closest('[data-go]'); if (!a) return; e.preventDefault();
    var i = parseInt(a.dataset.go, 10); uncase(true); near(i); pf.turnToPage(i); label(); rest(i); toggleToc(false); tb.focus();
  });
  /* 拡大：いまの頁（見開き）を原寸の画像で。スクロールで細部まで */
  var zm = $('.bk-zoom');
  function openZoom() {
    var i = pf.getCurrentPageIndex(), idx;
    if (pf.getOrientation() === 'portrait' || i === 0 || i === LAST) idx = [i];
    else { var a = i % 2 === 1 ? i : i - 1; idx = [a, a + 1]; }
    $('.pp', zm).innerHTML = idx.map(function (k) { var im = pages[k].querySelector('img'); return '<img src="' + (im.dataset.src || im.src) + '" alt="' + (im.alt || '') + '">'; }).join('');
    $('.zt', zm).textContent = $('.pgno').textContent;
    zm.hidden = false; $('.zc', zm).focus();
    var pp = $('.pp', zm); zm.scrollLeft = Math.max(0, (pp.scrollWidth - zm.clientWidth) / 2);
  }
  function closeZoom() { zm.hidden = true; $('.pp', zm).innerHTML = ''; $('.zm').focus(); }
  $('.zm').addEventListener('click', openZoom);
  $('.zc', zm).addEventListener('click', closeZoom);
  document.addEventListener('keydown', function (e) {
    if (zm.hidden) return;
    if (e.key === 'Escape') closeZoom();
    else if (e.key === 'Tab') { e.preventDefault(); $('.zc', zm).focus(); }      // 拡大のあいだは、閉じるボタンから出ない
  });
  var fs = $('.fs');
  if (!document.fullscreenEnabled) fs.hidden = true;
  fs.addEventListener('click', function () {                     // 断られたときに止まらないように（GPT 全站 R1）
    try {
      var r = document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
      if (r && r.catch) r.catch(function () {});
    } catch (e) {}
  });
  document.addEventListener('fullscreenchange', function () { setTimeout(fit, 120); });
  setLang(root.dataset.lang || 'ja');
})();
